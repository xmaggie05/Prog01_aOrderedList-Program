package Prog01_aOrderedList;
//Name: Maggie Xiao
//LSU ID: 8988988653
// Lab section: 002 

import java.util.Arrays;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Prog01_aOrderedList {
	public static void main(String[] args) throws FileNotFoundException{
		Prog01_aOrderedList program = new Prog01_aOrderedList(); //creates an object from Prog01_aOrderedList class
		aOrderedList orderedList = new aOrderedList(); // creates an object from aOrderedList class
		
		try {
			//Get input frile from user
			Scanner input = program.getInputFile("Enter input filename: ");
			//Goes through each line of the input file
			while (input.hasNextLine()) {
				String line = input.nextLine();
				String[] parts = line.split(",");
				//check if each line contains 4 parts
					if(parts.length == 4) {
						String operation = parts[0];
						//If "A" appears, the car's details are formed and added to the ordered list
						if (operation.equals("A")) {
						String make = parts[1];
						int year = Integer.parseInt(parts[2]);
						int price = Integer.parseInt(parts[3]);
						
						orderedList.add(new Car(make, year, price));
						}
						
					}else if (parts[0].equals("D")) {
				        // Process delete operation
				        String make = parts[1];
				        int year = Integer.parseInt(parts[2]);

				        // Search for the car in the ordered list
				        int indexToDelete = -1;
				        for (int i = 0; i < orderedList.size(); i++) {
				        	//if make and price from the input file match the one from list, the index is recorded to be delete
				            Comparable car = orderedList.get(i);
				            if (((Car) car).getMake().equals(make) && ((Car) car).getYear() == year) {
				                indexToDelete = i;
				                break;
				            }
				        }
				        // If the car is found, remove it from the list
				        if (indexToDelete != -1) {
				            orderedList.remove(indexToDelete);
				        }
				        
					}
			
				}
		}catch(FileNotFoundException e) {
			System.out.println("File not found. Please enter a valid filename");
		}
		System.out.println("File Exist");
		
		//creates an object of Prog01_aOrderedList to handle output operations
		Prog01_aOrderedList output = new Prog01_aOrderedList();
		PrintWriter outputFile = null; // initialize PrintWriter for writing output to the output file
        try {
            outputFile = output.getOutputFile("Enter the filename for output: ");
            if (outputFile != null) {
            	System.out.println("Output File Is Open Successfully");
            	//Write the number of cars in the odered list to the outputfile
            	 outputFile.printf("Number of cars: %10d\n\n" ,orderedList.size());
            	 // iterate through the ordered list and write car details to the output file
	            for (int i = 0; i < orderedList.size(); i++) {
	                Car car = (Car) orderedList.get(i); // get the car at index i
	               //Write the car details to the output file aligned
	                outputFile.printf("Make: %15s\n", car.getMake());
	                outputFile.printf("Year: %15s\n", car.getYear());
	                outputFile.printf(String.format("Price: %8s%,d", "$" , car.getPrice()));
	                outputFile.println();
	                //Add an extra line between each car's details, except for the last one
	                if (i < orderedList.size() - 1) {
	                 outputFile.println();
	                	
	               }
					
	            }
	           
            }
                 
        } catch (FileNotFoundException e) {
            System.out.println("Ends program");
        } finally {
            if (outputFile != null) {
                outputFile.close();
            }
        }
}
	/*
	 * Prompts the user to enter the filename for input and returns a Scanner object to read from the file.
	 * 
	 * CSC 1351 Programming Project No 2
	 * Section 002
	 * 
	 * @param userPrompt - a message to prompt the user for input filename
	 * @return - a Scanner object to read from the input file
	 * @author Maggie Xiao
	 * @since 3/17/24
	 */
	 public Scanner getInputFile(String userPrompt) throws FileNotFoundException {
		 //Creates a scanner to read user input
		 Scanner scan = new Scanner(System.in);
	     boolean program = true; //determines if the program should continue to run
	     // loops until the program is endered
	     while (program) {
	    	 try {
	    		 System.out.println(userPrompt);
	             String fileName = scan.nextLine().trim(); // clear any white spaces
	             File newFile = new File(fileName);
	             //if a file exists, a new Scanner is created to read from the file
	             if (newFile.exists()) {
	            	 Scanner fileScanner = new Scanner(newFile);
	                 if (fileScanner.hasNextLine()) {
	                    // File has data, return Scanner for input
	                    return fileScanner;
                    } else {
                        // File is empty, prompt user to enter another filename
                        System.out.println("The file <" + fileName + "> is empty. Please enter another filename:");
                    }
	                    
                } else {
                	//if the file does not exits, prompt the user to continue or not
                    while (true) {
                        System.out.println("\nFile specified <" + fileName +  "> does not exist. "
                        		+ "Would you like to continue? <Y/N>");
                        String option = scan.nextLine().trim(); // Read the option input
                        //if the user chooses not to continue, throw FileNotFoundException to end the program
                        if (option.equalsIgnoreCase("N")) {
                            throw new FileNotFoundException();
                        } else if (option.equalsIgnoreCase("Y")) {
                            break; // Exit the loop and re-prompt for file name
                        } else {
                        	//if the user enter an invalid choice, prompt them to enter "Y" or "N"
                            System.out.println("Please enter y or n:");
                        }
                    }
                }
	            } catch (FileNotFoundException e) {
	            	System.out.println("End Program");
	                program = false; // Ends the program
	            }
	        }
	       
	        return scan;
	  }

	/*
	 * Prompts the user to enter the filename for output and returns a PrintWrite object to write to the file.
	 * 
	 * CSC 1351 Programming Project No 2
	 * Section 002
	 * 
	 * @param userPrompt - a message to prompt the user for output filename
	 * @return - a PrintWriter object to write to the output file
	 * @author Maggie Xiao
	 * @since 3/17/24
	 */
	public PrintWriter getOutputFile(String userPrompt) throws FileNotFoundException {
		Scanner scanner = new Scanner(System.in);
	    PrintWriter outputFile = null;
	    boolean program = true;
	    //Loop until a valid output file is provided or the user chooses to end the program
	    while (program) {
	    	try {
                System.out.println(userPrompt);
                String fileName = scanner.nextLine().trim(); // clear any white spaces
                File newFile = new File(fileName);
                //check if the file exist
                if (newFile.exists()) {
                    return new PrintWriter(newFile);
                } else {
                //if the file doesn't exist, prompt the user to continue or not
                    while (true) {
                        System.out.println("\nFile specified <" + fileName +  "> does not exist. "
                        		+ "Would you like to continue? <Y/N>");
                        String option = scanner.nextLine().trim(); // Read the option
                        if (option.equalsIgnoreCase("N")) {
                            throw new FileNotFoundException();
                        } else if (option.equalsIgnoreCase("Y")) {
                            break; // Exit the loop and re-prompt for file name
                        } else {
                        	//if the user enter an invalid choice, prompt them to enter "Y" or "N"
                            System.out.println("Please enter y or n:");
                        }
                    }
                }
            } catch (FileNotFoundException e) {
                System.out.println("End Program");
                program = false; // Ends the program
            }
	    }
	   
	    return outputFile;
	}
	
	
}


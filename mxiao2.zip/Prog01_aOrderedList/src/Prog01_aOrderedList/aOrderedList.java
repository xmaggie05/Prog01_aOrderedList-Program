package Prog01_aOrderedList;

import java.util.Arrays;
import java.util.NoSuchElementException;

/*
 * Manages an ordered list of Car objects sorted based on make, year and price
 * Include methods for adding, accessing, and removing elements.
 * 
 * CSC 1351 Programming Project No 2
 * Section 002
 * 
 * @author Maggie Xiao
 * @since 3/17/24
 */
class aOrderedList{
	final int SIZEINCREMENTS = 20; //size of increments for increasing ordered list
	private Comparable[] oList;  //the ordered list
	private int listSize;  //the size of the ordered list
	private int numObjects;  // the number of objects in the ordered list
	private int curr; //index of current element accessed via iterator method
	
	//Constructor for aOrderedList class
	public aOrderedList() {
		numObjects = 0; //sets the numObjects to 0
		listSize = SIZEINCREMENTS; // set listSize to the value of SIZEINCREMENTS
		oList = new Comparable[SIZEINCREMENTS]; //instantiates the array oList to an array of size SIZEINCREMENTS
	}

	/*
	 * Adds the newObject object to the sorted array in the correct position to maintain sorted order
	 * 
	 * CSC 1351 Programming Project No 2
	 * Section 002
	 * 
	 * @param newObject - new objects to add
	 * @author Maggie Xiao
	 * @since 3/17/24
	 */
	void add (Comparable newObject) {
		if (numObjects == oList.length) {
            // If the array is full, resize it
             oList = Arrays.copyOf(oList, oList.length * 2);
        }

        int index = 0; //initialize index to 0
        //Find the correct position to insert the new Car object based on the sorting criteria
        while (index < numObjects && newObject.compareTo((Car) oList[index]) > 0) {
            index++;
        }
        
        // Shifting existing elements to make space for the new car object 
        System.arraycopy(oList, index, oList, index + 1, numObjects - index);
        
        //insert the new car at the correct position
        oList[index] = newObject;
        numObjects++;
    }
	
	/*
	 * Generates a String representation of the list of cars.
	 * 
	 * CSC 1351 Programming Project No 2
	 * Section 002
	 * 
	 * @return - a string represent of the list of cars
	 * @author Maggie Xiao
	 * @since 3/17/24
	 */
	@Override
	public String toString() {
		StringBuilder format = new StringBuilder();
		//Iterate through the list of cars
		for (int i = 0; i < numObjects; i++) {
	        Car car = (Car) oList[i];
	        //Adds formatted string representation of each car
	        format.append(String.format("[Make: %10s, ", car.getMake()));
	        format.append(String.format("Year: %8d, ", car.getYear()));
	        format.append(String.format("Price: %9s%,d]", "$", car.getPrice()));
	        
	        if (i < numObjects - 1) {
	            format.append("\n"); // Add a newline and space after each entry except the last one
	        }
	    }
	    return format.toString();
	}
	
	/*
	 * Returns the number of elements in  this list
	 * 
	 * CSC 1351 Programming Project No 2
	 * Section 002
	 * 
	 * @return - the number of elements in this list
	 * @author Maggie Xiao
	 * @since 3/17/24
	 */
	public int size() {
		return numObjects;
	}
	
	/*
	 * Returns the element at the specified position in the list
	 * 
	 * CSC 1351 Programming Project No 2
	 * Section 002
	 * 
	 * @param index - the index of the object to retrieve
	 * @return - object at the specified index
	 * @author Maggie Xiao
	 * @since 3/17/24
	 */
	public Comparable get(int index) {
		//if the index is not within the bounds, it throws an exception
		 if (index < 0 || index >= numObjects) {
	            throw new IndexOutOfBoundsException("Index is out of bounds");
	        }
	        return (Car) oList[index];
	}
	
	/*
	 * Checks if the array is empty or not
	 * 
	 * CSC 1351 Programming Project No 2
	 * Section 002
	 * 
	 * @return - returns true if the array is empty and false otherwise.
	 * @author Maggie Xiao
	 * @since 3/17/24
	 */
	public boolean isEmpty() {
		return numObjects == 0; //if the number of objects equals 0, the array is empty
	}
	
	/*
	 * Removes the object at the specified index from the list.
	 * 
	 * CSC 1351 Programming Project No 2
	 * Section 002
	 * 
	 * @param curr - index of the object to remove
	 * @author Maggie Xiao
	 * @since 3/17/24
	 */
	public void remove(int curr) {
		//check if the index is within bounds
        if (curr < 0 || curr >= numObjects) {
            throw new IndexOutOfBoundsException("Index is out of bounds");
        }
        for (int i = curr; i < numObjects - 1; i++) {
            oList[i] = oList[i + 1]; // Shift elements to the left
        }
        oList[numObjects - 1] = null; // Set the last element to null
        numObjects--; // Decrement the number of objects
    }
	
	/*
	 * Resets iterator parameters so that the "next" element is the first element in the array, if any
	 * 
	 * CSC 1351 Programming Project No 2
	 * Section 002
	 * 
	 * @author Maggie Xiao
	 * @since 3/17/24
	 */
	public void reset() {
		curr = 0; // sets the index to 0
	}
	
	/*
	 * Return the next element in the iteration and increments the iterator parameter
	 * 
	 * CSC 1351 Programming Project No 2
	 * Section 002
	 * 
	 * @param curr - next object in the iteration
	 * @author Maggie Xiao
	 * @since 3/17/24
	 */
	public Comparable next() {
		//checks if there are more elements in the iteration
		if (!hasNext()) {
            throw new NoSuchElementException("There are no more elements in the iteration");
        }
        return oList[curr++]; // return the next object and increment the current index
	}
	
	/*
	 * Returns true if the iteration has more elements to iterate through
	 * 
	 * CSC 1351 Programming Project No 2
	 * Section 002
	 * 
	 * @param curr - next object in the iteration
	 * @author Maggie Xiao
	 * @since 3/17/24
	 */
	public boolean hasNext() {
		// check if the iteration has more elements
		return curr < numObjects; 
		
	}
	
	
}
	
	
	






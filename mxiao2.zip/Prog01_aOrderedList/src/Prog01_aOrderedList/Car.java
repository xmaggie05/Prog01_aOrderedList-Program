package Prog01_aOrderedList;

/*
 * Represents individual car object's characteristics, including its make(model of the car), year of manufacture, and price. 
 * Provide method in comparison of cars based on it's characteristics
 * 
 * CSC 1351 Programming Project No 2
 * Section 002
 * @author Maggie Xiao
 * @since 3/17/24
 */
class Car implements Comparable<Car>{
	//member variables
	private String make; // the model of the car
	private int year; // the year the car was made
	private int price; // the price of the car

	//Constructor for Car Class
	public Car (String make, int year, int price) {
		this.make = make;
		this.year = year;
		this.price = price;
	}
	/*
	 * Returns the make of the object
	 * 
	 * CSC 1351 Programming Project No 2
	 * Section 002
	 * 
	 * @return - make of the object
	 * @author Maggie Xiao
	 * @since 3/17/24
	 */
	public String getMake() {
		return make; //return the value of the make
	}
	
	/*
	 * Returns the year of the object
	 * 
	 * CSC 1351 Programming Project No 2
	 * Section 002
	 * 
	 * @return - year of the object
	 * @author Maggie Xiao
	 * @since 3/17/24
	 */	
	public int getYear() {
		return year; //return the value of the year
	}
	
	/*
	 * Returns the price of the object
	 * 
	 * CSC 1351 Programming Project No 2
	 * Section 002
	 * 
	 * @return - price of the object
	 * @author Maggie Xiao
	 * @since 3/17/24
	 */
	public int getPrice() {
		return price; //returns the value of the price
	}
	
	/*
	 * Compare two cars based on their make and price.
	 * 
	 * CSC 1351 Programming Project No 2
	 * Section 002
	 * 
	 * @param other - the other car to compare with
	 * @return - a negative, zero, or positive integer if the car is less than, equal to ,or greater than the other car
	 * @author Maggie Xiao
	 * @since 3/17/24
	 */
	public int compareTo(Car other) {
		// if the makes are the same, compare the car based on their price
		if ((make.compareTo(other.make) == 0)) {
			 return (Integer.compare(price, other.price));
		}else {
			//else, return the results of comparing two car based on makes
			return make.compareTo(other.make);
		}
	
		}
	
	/*
	 * Returns values of make, year, and price as one string for each object
	 * 
	 * CSC 1351 Programming Project No 2
	 * Section 002
	 * 
	 * @return - a string representation of the car object
	 * @author Maggie Xiao
	 * @since 3/17/24
	 */
	@Override
	public String toString() {
		return "[Make: " + make + ", Year : " + year + ", Price: " + price + ";]";
	}
}
